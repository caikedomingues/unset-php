


<?php


    $texto = " conteudo da variável ";


    /*A função mb_strlen() serve para contar a quantidade de caracteres de uma string */

    $total_de_letras = mb_strlen($texto);

    echo "</p> Quantidade de letras do conteudo: $total_de_letras</p>";

    /*Também é possivel  usar uma função dentro da outra, nesse caso vamos usar a função trim que serve para eliminar os espaços do começo e do fim da string. */

    /*Utilização da função strlen que ira receber como parametro a função trim com a string */
    $total_sem_espacos = mb_strlen(trim($texto));

    echo "<p> total sem espaços: $total_sem_espacos</p>";

    /*Também é possivel resumir o texto atarvés da função mb_substr que recebe 3 parametros sendo eles: a string, o valor inicial e o valor final. */

    $resumo = mb_substr($texto, 2, 15);

    echo "<p> Resumo de um trecho do texto: $resumo</p>";

    $resumo_sem_espaco = mb_substr(trim($texto), 2, 15);

    echo "<p> Resumo do trecho sem espaços: $resumo_sem_espaco</p>";

    /*A função strrpos tem como intuito devolver a ultima posição de uma string, sendo assim, ela recebe 2 parametros: a string e a letra procurada*/

    $ocorrencia = mb_strrpos($texto, 'e');

    echo "<p> Ultima posição do caractere 'e': $ocorrencia </p>";



?>