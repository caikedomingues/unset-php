


<?php

    /*Vamos criar novamente a função para validar url´s, só que agora, ao invés de utilizar um filtro pronto, vamos criar manualmente os critérios que irão definir uma url */

    function validarUrl(String $url):bool{

        /*Primeiro, vamos verificar a quantidade de caracteres da url */

        /*O metodo mb_strlen serve para retornar o tamanho de uma string e recebe como parametro a string que será análisada.*/
        if(mb_strlen($url) < 10){

            /*Se o tamanho do link tiver menos de 10 caracteres a função ira retornar false */

            return false;
        }


        /*A segunda condição é verificar se o link possui o '.', para isso vamos utilizar o metodo str_contains() que recebe como parametro a string analisada e o valor buscado.*/

        if(!str_contains($url, ".")){

            /*Se a url não conter o ponto final a função ira retornar false. */
            return false;
        }


        if(str_contains($url, "http://") or str_contains("https://")){

            /*Se o link conter um 'http://' ou um 'https://' ele será valido e a função ira retornar true  */
            return true;
        }

        /*Valor padrão. */
        return false;


    }

?>