
<?php


/*Aqui iremos incluir o arquivo funcao.php e realizar a chamada dos metodos */
include 'funcao.php';

echo validarUrl("http://teste.com");


/*Aqui vamos verificar se o retorno da função é igual a 1: verdadeiro ou 0: falso. */
if(validarUrl("http://teste.com") == 1){

    echo "<p> url válida</p>";

}else{

    echo "<p> url inválida</p>";
}

/*Resumindo: segundo o professor, para validações mais simples é recomendado criar os filtros.*/
?>


