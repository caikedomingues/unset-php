







<?php

  

   /*O namespace recebe o diretório pai e o diretório que guarda as classes ou arquivos do projeto. */

   namespace  unsetphp\namespace;

  class Mensagem{

    private $texto = "conteudo";
    private $css;


    /*Métodos mágicos são métodos especiais que sobrescrever o comportamento padrão do PHP quando certas operações são realizadas em um objeto. Todos os métodos prefixados com __ são reservados pelo PHP. Portanto, não é recomendado utilizar nomes de métodos com esse prefixo a não ser para sobrescrever o comportamento do PHP. */
    /*Todos os metodos mágicos devem ser declarados como public */

    /*O php reserva todas as funções com nomes iniciadas com '__' como mágicas. É recomendado que não se utilize funções com nomes '__' no PHP, a não ser que deseje-se alguma funcionalidade mágica documentada  */


    /*Vamos utilizar o metodo toString  */

    public function __toString(){

        return $this->renderizarCss();
    }


    /*Até onde compreendi esse metodo magico, realiza conversões para string */
    public function renderizarCss():String{

        return "<div class = '{$this->css}'>{$this->texto}</div>";
    }




  }






?>