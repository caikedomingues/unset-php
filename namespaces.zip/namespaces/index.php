





<?php


    include './namespace/unsetphp/Mensagem.php';

    /*Como agora eu defini um namespace, tenhoq ue colocar o caminho das pastas na instanciação. */

    use unsetphp\namespace\Mensagem;
    
    echo (new Mensagem())->renderizarCss();

?>