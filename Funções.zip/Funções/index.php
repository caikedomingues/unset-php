

<?php


    /*Como a função está em outro arquivo, devemos inclui-la nesse arquivo e depois chamar a função desejada */
    include 'funcao.php';

    /*Aqui iremos chamar a função e executa-la */
    echo saudacao();

    echo "<p>".resumirTexto()."</p>";
?>