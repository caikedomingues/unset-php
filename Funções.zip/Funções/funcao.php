




<?php 

    /*Apesar de não ser obrigatório fazer dessa maneira, é uma boa prática de programação escrever as funções assim: */
    function saudacao()
    {

        /*Não é recomendado a utilização de echos em funções */
        return 'boa tarde';
        
    }


    function resumirTexto(){

        return "texto resumido";
    }


?>