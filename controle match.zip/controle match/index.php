


<?php


    include 'funcao.php';
?>