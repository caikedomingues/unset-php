


<?php

    
    /*Para iniciar o exercicio irei criar uma variável hora que ira receber um valor do tipo string. */
    
    date_default_timezone_set('America/Sao_Paulo');

    $hora = date('H');

    /*Agora vamos usar a estrutura match para dar saudações ao usuário. Para isso, vamos criar a variável saudação que ira receber a função match que terá como parametro a variável hora.  */

    /*Observação: aparentemente função match só analisa dados do tipo texto */
    $saudacao = match($hora){

        /*Dentro da estrutura, vamos analisar o valor da variável hora e dependendo do seu resultado a variável saudação ira receber um determinado valor */

        $hora >= 0 and $hora <= 5 => 'Boa madrugada',

        $hora >= 6 and $hora <= 12 => 'Bom dia',

        $hora >= 13 and $hora <= 18 => 'Boa tarde',

        $hora >= 18 => 'Boa noite',

        /*Valor padrão */
        default => 'Olá usuário'
       

    };

    /*Impressão do resultado */
    echo $saudacao;






?>