


<?php

    include 'funcao.php';

    echo saudacao();

?>
