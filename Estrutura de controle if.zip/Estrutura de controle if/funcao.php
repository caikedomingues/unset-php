

<?php

    function saudacao()
    {
        
        /*Nesse exercicio, vamos atribuir a variável hora a função date que ira receber como parametro o valor 'H:i' que ira retornar as hoars e os minutos exatos do sistema */
        /*Antes de passarmos o horário, é necessário configurar o timezone do php para o formato brasileiro */

        /*Código para configuraçaõ do timezone */
        date_default_timezone_set('America/Sao_Paulo');

        $hora = date('H:i');

        if($hora >= 0 && $hora <= 5){

            return "bom madrugada: agora são $hora horas";

        }elseif($hora >= 6 && $hora <= 12){

            return "bom dia: Agora são $hora horas";

        }else if($hora > 12 && $hora <=17){

            return "boa tarde agora são $hora horas";

        }elseif($hora > 17 && $hora <= 23){

            return "boa noite: agora são $hora horas";
        }
    }

?>