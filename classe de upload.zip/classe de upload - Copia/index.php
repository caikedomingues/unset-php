<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Classe upload</title>
</head>
<body>


    <?php
    
        $arquivo = $_FILES['arquivo'];
    
    ?>
    <form action="<?php $_SERVER['PHP_SELF']?>" method="post" enctype="multipart/form-data">
    <label for="arquivo"> Arquivo</label><br>
    <input type="file" name="arquivo"><br>
    <input type="submit" value="ENVIAR">
    </form>

    <?php
        include 'Upload.php';

        /*Antes de iniciar qualquer operação, vamos verificar se o 
        campo do arquivo já foi preenchido */

        if(!empty($arquivo = $_FILES['arquivo'] )){
            /*Agora vamos criar uma nova pasta */
            $upload = new Upload('uploadteste');
            /*Vamos criar um subdiretório */
            $upload->arquivo($arquivo, null, 'pastateste');

            var_dump($arquivo);
           
        }
    ?>

</body>
</html>