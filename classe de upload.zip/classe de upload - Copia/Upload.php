

<?php

    class Upload{

        private string $diretorio;
        private array $arquivo;
        private string $nome;
        private string $subdiretorio;

        /*No nosso construtor vamos passar como parametro uma string
        diretorio que tera como valor inicial nulo */
        public function __construct(string $diretorio = null){

            /*Aqui vamos usar a tecnica da "equivalencia" (não sei
            se o nome está correto) para atribuir valor a variável diretório.
            Se o valor do parametro naõ for nul0 a variável diretório ira receber
            o valor do parametro, caso contrário ira receber um valor padrão */
            $this->diretorio = $diretorio ?? 'uploads';

            /*Agora vamos verificar o se o valor passado é um arquivo 
            que existe e se o arquivo é um diretório, caso o arquivo não
            exista ou não seja do tipo diretório, vamos criar uma pasta
            com a variável diretorio com a permissão 0755 */

            /*Até onde entendi, o metodo file_exists verifica se um
            determinado arquivo existe ou não em um determinado sistema. */
            if(!file_exists($this->diretorio && !is_dir($this->diretorio))){

                mkdir($this->diretorio, 0755, true);

            }
        }


        /*No metodo arquivo, vamos criar as pastas que iremos guardar nos subdiretórios. o metodo terá como parametro uma string que sera o caminho da pasta e o nome do arquivo*/
        public function arquivo(array $arquivo,string $nome = null, string $subdiretorio = null){

            $this->arquivo = $arquivo;
            /*A variável nome ira receber o nomo do arquivo escolhido pelo usuário e caso o mesmo não escolha um nome, vamos usar o metodo pathinfo(até onde entendi serve para pegar informações do path) que tera como parametro o nome do arquivo e o pathinfo_filename que ira pegar o nome do arquivo.*/
            $this->nome = $nome ?? pathinfo($this->arquivo['name'], PATHINFO_FILENAME);

            $this->subdiretorio = $subdiretorio ?? 'arquivos';

            /*Essa variável irá pegar a extensão do arquivo.*/
            $extensao = pathinfo($this->arquivo['name'], PATHINFO_EXTENSION);
            
            /*Agora que coletamos as extensões, vamos criar um array
            que terá as extensões que serão válidas no sistema  */

            $extensoesValidas = ['pdf', 'png', 'jpeg', 'jpg', 'docx', 'mp3', 'mp4'];

            /*Após finalizar o array, precisaremos verificar se o a extensão do documento escolhido está ou não na lista(array) de extensões validas. Para isso, vamos usar o metodo in_array que verifica se um determinado valor está ou não em um array. O metodo recebe dois parametros, um é o valor procurado e o outro é o array que será verificado.  */
            if(!in_array($extensao, $extensoesValidas)){

                /*Caso o valor da extensão nao esteja no array vamos imprimir uma mensagem informando ao usuário que a extensão não é permitida */
                echo "<p> Extensão não permitida</p>";

                echo "<p> Você só pode enviar arquivos com as extensões:</p>";

                /*Agora vamos criar um for que ira imprimir as extensões aceitas pelo sistema */

                /*Observação: Diferente do java, para descobrirmos o tamanho
                de um array, não utilizamos o length, utilizamos o count() que
                irá contar a quantidade de elementos do array. */
                for($i = 0; $i < count($extensoesValidas); $i++){

                    /*Impressão dos valores do array */
                    print($extensoesValidas[$i].' , ');
                }

                die;   
            }


            /*Chamadas de metodos */
            $this->criarSubdiretorio();
            $this->renomearArquivo();
            $this->salvarArquivo();

            

        }

        /*Até onde estou entendendo da aula, esse metodo ira criar um sub diretório dentro da pasta 'uploadteste'*/

        /*Observação: o directory separator, serve para utilizar o separador (normalmente as barras: /) de arquivos no endereço de arquivos e diretórios*/
        private function criarSubdiretorio(){

            /*Basicamente, ele está verificando se existe algum diretório dentro do diretório que estamos criando  */
            if(!file_exists($this->diretorio).DIRECTORY_SEPARATOR.$this->subdiretorio){

                /*Agora que ja verificamos tudo, vamos criar o sub diretório dentro da pasta */
                mkdir($this->diretorio.DIRECTORY_SEPARATOR.$this->subdiretorio, 0755, true);
            }
        }
        
        private function renomearArquivo(){

            /*Aqui vamos pegar só a extensão do arquivo do arquivo */
            $arquivo = $this->nome.strrchr($this->arquivo['name'], '.');
            if(file_exists($this->diretorio.DIRECTORY_SEPARATOR.$this->subdiretorio.DIRECTORY_SEPARATOR.$arquivo)){

                $arquivo = $this->nome.'-'.uniqid().strrchr($this->arquivo['name'],'.');

            }else{

                $this->nome = $arquivo;
            }
        }

        private function salvarArquivo(){

            /*Aqui vamos guardar o arquivo escolhido em uma determinada pasta, para isso vamos usar o metodo move_upload_file que receberá como parametro o arquivo e a pasta que o arquivo será armazenado.*/
            if(move_uploaded_file($this->arquivo['tmp_name'], $this->diretorio.DIRECTORY_SEPARATOR.$this->subdiretorio.DIRECTORY_SEPARATOR.$this->arquivo['name'])){

                echo "<p> arquivo movido com sucesso</p>";

            }else{

                echo "<p>Não foi possivel mover o arquivo</p>";
            }
        }


    }

?>