


<?php


include 'funçao.php';

/*Como um dos parametro ja possui um valor padrão, não sou obrigado a colocar ele na passagem de parametros  */
echo funcaoComParametro("texto", "olá");

/*Agora eu reescrevi o valor da variável $continue que tinha um valor padrão */
echo "<p>".funcaoComParametro("carapicuiba", "osasco", "barueri")."</p>";

?>