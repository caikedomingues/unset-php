


<?php

    /*Assim como em outras linguagens, as funções podem receber parametros */

    /*Nessa função em especifico, vamos criar 2 parametros sem valor e um com valor especifico que, caso não sofra alterações tenha um valor padrão. */

    function funcaoComParametro($texto, $limite, $continue='...')
    {
        return "texto com parametro: $texto, $limite, $continue";
    }
?>