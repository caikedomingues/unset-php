




<?php


    /*Nesse exercicio, vamos utilizar o try e o catch */


            /*A função terá como objetivo, validar um cpf, ele ira receber como parametro uma string e retornara valores booleanos. */

              function validarCpf(String $cpf): bool{

                /*primeiro vamos verificar o tamanho do cpf, e só será valido se o cpf conter 11 digitos */
    
                if(mb_strlen($cpf) != 11 or preg_match('/(\d)\1{10}/', $cpf)){
                    /*SE a quantidade de digitos for menor que 11, a função a função ira criar / instanciar uma exceção*/
    
                    throw new Exception ('O cpf precisa ter 11 digitos');
                }
    
                 /*Retorno padrão da função */
                    return true;
            }


            /*Aqui embaixo, vamos verificar o resultado do metodo */

            try{

                /*Debtro do bloco try, vamos verificar um determinado bloco */
                validarCpf('1234');

               

            }catch(Exception $e){

                /*Dentro do catch, vamos especificar o catch e trabalhar a exceção  */

                /*Observação: para o tratamento funcionar, foi necessário criar a classe Exception dentro do método */
                echo "<p> try e catch: o cpf deve conter 11 digitos: $e</p>";

            }finally{

                /*Sempre é executado, após o try e o catch independente do resultado. */

                echo "Fim do programa";
            }



?>