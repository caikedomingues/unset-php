


<?php


    include 'Pessoa.php';    


    $pessoa = new Pessoa();

    $cpf = '12345678911';

    $cpf2 = '1234';

    echo $pessoa->validarCpf($cpf);


    $pessoa2 = new Pessoa2();

    echo $pessoa2->validarCpf($cpf2);


    /*Caso o cpf seja válido, vamos apresentar uma mensagem ao usuario */

    /*Se o resultado for igual a verdadeiro, vamos informar o usuário com uma mensagem. */
    if($pessoa->validarCpf($cpf) == 1){

        echo "<p> Cpf válido</p>";

        echo "<p> Valor informado: $cpf</p>";
    }





    




?>