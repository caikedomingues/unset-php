



<?php


    include 'funcao.php';

    /*while: significa enquanto */

    /*Vamos criar uma variavel numero que terá como valor inicial o valor 0. */

    $numero = 0;

    /*Agora, vamos utilizar a estrutura while para imprimir do valor 0 até o  valor 10. */

    while($numero < 10){

        /*Enquanto o valor de $numero for menor que 5 o while ira adicionar mais um na contagem. */
        $numero = $numero + 1;

        echo  " ".$numero;
    }


    /*Vamos realizar a mesma tarefa só que agora com a estrutura for(para) que basicamente, trabalha com 3 valores:
    
    1° valor = valor inicial

    2° valor = uma comdição,

    3° valor: incremento ou decremento
    */


    for($i = 0; $i <= 10; $i++){

        echo "<p> $i </p>";
    }

    /*Usando o for vamos imprimir apenas os valores pares do intervalo entre 0 e 10. */

    for($i = 0; $i <= 10; $i++){

        if($i % 2 == 0){

            echo "<p> valor par: $i</p>";
        }
    }

    for($i = 0; $i <= 10; $i++){

        if($i % 2 != 0){

            echo "<p> valor impar: $i </p>";
        }
    }


?>