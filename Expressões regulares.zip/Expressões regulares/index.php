



<?php

    /*Inclusão do arquivo 'funcao.php' para possibilitar a chamada de metodos */
    include 'funcao.php';

    /*Criação da variável cpf */
    $cpf = '123.456.789-00';

    echo "<p>".validarCpf($cpf)."</p>";

    /*Validação da resposta do método */
    if(validarCpf($cpf) == 1){

        echo "<p> cpf válido</p>";

    }else{

        echo "<p> cpf inválido</p>";
    }


?>