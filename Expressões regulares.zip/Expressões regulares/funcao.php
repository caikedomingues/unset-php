


<?php

    

   
    /*Criação da função para validar cpf que ira receber como parametro uma string e retorna uma valor booleano */

    function validarCpf(string $cpf): bool{

        /*Chamada do metodo limparNumero */

        $cpf = limparNumero($cpf);

        /*Dentro do metodo iremos verificar a quantidade de digitos do cpf  */
        if(mb_strlen($cpf) != 11 || preg_match('/(\d)\1{10}/', $cpf)){

            /*Caso o cpf seja menor que 11 ou tenha digitos repetidos a função ira retornar false */

            return false;
        }

        /*retorno padrão da função */

        return true;
    }


    /*A função numero terá como objetivo eliminar os caracteres especiais para  considerar apenas os numeros na contagem de caracteres*/
    function limparNumero(String $numero): string{

        return preg_replace('/[^0-9]/', '',$numero);


    }

?>