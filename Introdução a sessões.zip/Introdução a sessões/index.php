



<?php

    /*Antes de iniciarmos uma sessão, devemos utilizar o metodo session_start para dar inicio a criação e utilização das seções */

    session_start();

    /*Agora que ja criamos uma seção para o nosso servidor, podemos verificar algumas funcionalidades, como por exemplo,  
    o id da seção do servidor*/

    /*Cada seção criada terá um id diferente */
    echo session_id();

    /*As seções são arrays, então para atribuir valor a elas vamos usar a variável super global $_SESSION que ira conter as informações */

    /*Como exemplo, vamos criar uma seção para nomes */

    $_SESSION['nome'] = 'Caike de Oliveira';

    /*Nesse outro exemplo, vamos criar uma seção para conter as visitas feitas no site. */
    $_SESSION['visitas'];

    /*Agora vamos verificar se a variável session foi acessada, e caso a verificação seja verdadeira, iremos atribuir uma visualização a mais na variável session de visitas */

    if(isset($_SESSION['visitas'])){

        $_SESSION['visitas'] = $_SESSION['visitas'] + 1;

    }else{

        $_SESSION['visitas'] = 1;
    }

    /*Agora, vamos elaborar a mensagem de impressão com os resultados */

    echo "</p>".$_SESSION['nome']." visitou ".$_SESSION['visitas']." vezes<p>";

    /*Seções servem para configurar o servidor e salvar informações */

    /*Se quisermos limpar uma seção, basta, usar o metod unset($_SESSION['nome da sessão']) ou podemos utilizar a função session_destroy() */


    include 'Sessao.php';

    $sessao = new Sessao();

    echo $sessao->criar();

    echo $sessao->checar();

    echo $sessao->limpar();

    echo $sessao->checar();

    //echo $sessao->deletar();

    echo session_id();
?>  