


<?php

    /*Como as sessões são globais, ao cria-las, posso acessa-las de qualquer lugar do código. */

    class Sessao{

        /*Para iniciar, vamos utilizar um construtor para que terá como valor padrão uma estrutura que ira verificar se existe ou não uma seção criada */

        public function __construct(){

            /*Aqui dentro vamos verificar se existe o id de uma seção */

            if(!session_id()){

                /*Se não existir um id de seção (o que significa que uma sessão não foi iniciada ou criada), vamos dar inicio a uma sessão */

                session_start();
            }
        }

        /*Os metodos a seguir foram exercicios propostos pelo professor, logo é a minha interpretação de como os metodos devem funcionar */

        /*Metodo para criação da sessão */

        public function criar(){

            /*Esse metodo irá criar a sessão */
            $_SESSION['objetos'] = 'Caneta';
        }

        /*Função que irá limpar os valores da sessão */
        public function limpar(){

            unset($_SESSION['objetos']);
        }

        /*A função carregar terá como objetivo escrever o valor da sessão na tela, porém, ela será uma função privada, já que antes de imprimir uma mensagem,é necessário verificar se a sessão foi inicializada. */
        private function carregar(){

            echo "<p>você escreveu ".$_SESSION['objetos']." na sessão </p>";
        }


        /*Metodo que ira verificar se a sessão possui um valor */
        public function checar(){

            /*Dentro do metodo, vamos verificar se existe um valor na sessão */
            if(isset($_SESSION['objetos'])){
                /*Caso a sessão esteja inicializada, o metodo ira chamar o outro método para imprimir a mensagem com o valor da sessão.*/
                $metodo =$this->carregar();
            }else{

                /*Caso contrário o sistema ira informar ao usuário que não há valores na sessão */
                echo "<p> não há nada na sessão</p>";
            }
        }

        /*Função que será responsável por apagar a sessão do sistema */
        public function deletar(){

            session_destroy();
        }

        
    } 
?>