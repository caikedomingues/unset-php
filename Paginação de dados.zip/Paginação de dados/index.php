



<?php

    /*Primeiro, vamos criar um array que terá os dados que serão trabalhados */

    $dados = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20,21];

    $limite = 5; //quantidade de limite de paginas que podem ser extraidas

    /*Para permitir a alteração dos dados na passagem de páginas, vamos atribuir
    como valor inicial uma superglobal get que terá como indice a variável página
    que futuramente será responável por capturar a página do sistema.  */
    $offset = ($_GET['pagina'] - 1) * $limite; // Posição inicial da extração

    /*Agora na variável paginação, vamos utilizar o metodo array_slice()  que tem o intuito de fatiar os dados, pois ele extrai partes/pedaços do array. O metodo recebe 3 parametros, o array que sera análisado, offset que é o posição inicial da extração, length que é o numero de dados que serão extraidos, caso o length não contenha nenhum valor, ele ira terminar a extração no final do array.  */
    $paginacao = array_slice($dados, $offset, $limite);
    
    /*Agora vamos percorrer a variável de paginação */
    foreach($paginacao as $pagina){

        echo "<p>".$pagina."</p>";
    }

    /*Agora vamos trabalhar a captura do valor escolhido pelo usuário dentro da url  */
     $pagina = filter_input(INPUT_GET, 'pagina', FILTER_VALIDATE_INT ??1);


    /*Agora vamos apenas imprimir o total de páginas disponiveis, para isso vamos dividir o total dos dados com o limite, pois, caso o array dados tenha os seus valores atualizados, a quantidade limite de paginas também será alterada. */

    /*A função ceil tem como objetivo arredontar (sempre pra cima) os valores decimais*/
    $total_paginas  = ceil(count($dados) /  $limite);


     /*Impressão dos resultados da navegação */
    echo "<p> Valor escolhido: ".$pagina."</p>";

    echo "<p> Pagina ".$pagina." de ".$total_paginas."</p>";


    /*Agora, vamos criar a navegação das paginas através de links html, para isso vamos verificar se o valor é maior que 1. */
    if ($pagina > 1) {
        /*Se o valor for maior que 1 vamos usar o botão "anterior" para voltar uma página. */
        echo '<p> <a href="?pagina=' . ($pagina - 1) . '">anterior</a>  </p>';

    }
    
    /*Na parte de avançar a página vamos verificar se o valor da página é menor que o valor total de paginas */
    if($pagina < $total_paginas){

        /*Se a condição for satisfeita, vamos apenas avançar a página atribuindo mais 1 na contagem */
        echo '<p> <a href="?pagina=' . ($pagina + 1) . '">Próximo </a> </p>';
    }
    






?>