

<?php

    /*A maneira mais segura de extrair os valores dos formulários é através de filtros */
    
    /*Nesse caso em especifico, a variável ira receber o filtro de inputs que é um array, pois, iremos passar vários dados aos formulários, o metodo do filtro será o padrão, ou seja, o default. */
    $dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

    /*Agora, vamos verificar se as variáveis foram inicializadas, e caso elas contenham valores, vamos imprimi-los na tela. */
    if(isset($dados)){

        echo "<p>".$dados['nome']."</p>";
        
        echo "<p>".$dados['senha']."</p>";
    }

?>


<form action="" method="post">

    <label for="nome">Nome:</label>
    <input type="text" name="nome" autocomplete="off"><br><hr>

    <label for="senha">Senha:</label>
    <input type="text" name="senha" autocomplete="off"><br><hr>

    <input type="submit" value="Enviar">
</form>