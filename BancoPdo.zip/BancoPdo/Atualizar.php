



<!DOCTYPE html>
<html lang="pt-br">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale 1.0">
        <meta http-equiv="X-UA Compatible" content="IE-edge">
        <link rel="stylesheet" href="estilo/estilo.css">
    </head>

    <body>
        <header>
            <h1>Banco de dados com PDO</h1>
        </header>

        <main>
            <!--Menu de opções do sistema-->
            <ul>
                <li><a href="Apagar.php">Apagar dados</a></li>

                <li><a href="index.html">Inicio</a></li>

                <li><a href="Inserir.php">Inserir dados</a></li>

                <li><a href="Selecionar.php">Pesquisar dados</a></li>

            </ul>
        </main>

        <section>

            <?php

                 /*Captura dos valores passados pelo o usuário */
                $id = $_GET['id'] ?? 0;////valor padrão caso o usuário não informe nenhum valor

                $tipo = $_GET['tipo'] ??"nenhum tipo alterado";//valor padrão caso o usuário não informe nenhum valor

                $modelo = $_GET['modelo']?? "nehum modelo alterado";//valor padrão caso o usuário não informe nenhum valor

                $placa = $_GET['placa']?? "Nenhuma placa alterada";//valor padrão caso o usuário não informe nenhum valor

            ?>

              <!--Criação do formulário-->
            <!--O formulário ira fazer referencia a variavel SERVER, que ira mandar as informações para as variáveis em php.O metodo será get, pois queremos pegar a informação-->
            <form action="<?php $_SERVER=['PHP_SELF']?>" method="get">

             <!--Legenda do  formulário-->
            <label for="id">Informe o id do veiculo que será modificado:</label>

            <!--campo para inserção de dados: não possuem autocomplete e não podem ser vázios-->
            <input type="number" name="id" id="idid" autocomplete="off" required>

            <!--Legenda do  formulário-->
            <label for="tipo">Informe o novo tipo de veiculo:</label>

             <!--campo para inserção de dados: não possuem autocomplete e não podem ser vázios-->
            <input type="text" name="tipo" id="idtipo" autocomplete="off" required>

             <!--Legenda do  formulário-->
            <label for="modelo">Informe o novo modelo:</label>

            <!--campo para inserção de dados: não possuem autocomplete e não podem ser vázios-->
            <input type="text" name="modelo" id="idmodelo" autocomplete="off" required>

              <!--Legenda do  formulário-->
            <label for="placa">Informe a nova placa</label>

             <!--campo para inserção de dados: não possuem autocomplete e não podem ser vázios-->
            <input type="text" name="placa" id="idplaca" autocomplete="off" required>
            
             <!--Criação do botão de atualização de dados-->
            <input type="submit" value="alterar informações">
        
            </form>
        </section>
        <section>
            <?php

                /*Inclusão do arquivo que contem os metodos para manipular o banco de dados */
                include 'BancoDeDados.php';
                
                /*Instanciação do banco de dados */
                $banco = new BancoDeDados();

                /*chamada do Metodo apagar que irá receber como parametro o id, o tipo, o modelo e a placa. */
                $banco->atualizar($id, $tipo, $modelo, $placa);

                 /*Mensagem que indica os ultimos dados alterados */
                echo "<p> Dados alterados até o momento</p>";
                
                echo "<p> id: $id";

                echo "<p> Tipo: $tipo</p>";

                echo "<p> Modelo: $modelo</p>";

                echo "<p> placa: $placa</p>";
            
            
            ?>
        </section>

    </body>

</html>

