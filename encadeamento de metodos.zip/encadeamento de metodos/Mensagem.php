




<?php

 /*Os metodos dentro de uma classe / objeto servem para possibiltar que o objeto realize uma tarefa ou execute uma função. */



 class Mensagem{

    /*Dessa vez os atributos serão privados, ou seja, só poderão ser acessados dentro da própria classe.  */
    private $texto;
    private $css;

    /*encadeamento de metodos: Ocorre quando um método precisa de outro para funcionar perfeitamente. */

    /*Vamos criar uma função pública que receberá como parametro uma string e retornara o próprio objeto Mensagem. */

    public function sucesso(string $mensagem): Mensagem{

        /*Dentro do metodo iremos usar a palavra reservada 'this' (isto) para acessar a variável privada texto e o metodo privado filtrar */

        $this->css = 'alert alert-success';
        $this->texto = $this->filtrar($mensagem);

        /*retorne isto: resultado do metodo */
        return $this;
    }




    /*Os metodos também possuem visibilidade */

    /*Vamos criar uma função pública que terá como finalidade imprimir o valor da variável texto. Vamos precisar desse método porque o  nosso atributo é privado, ou seja, não pode ser acessado fora da classe. */

    /*O metodo não contera parametros e ira retornar valores do tipo string */

    /*Esse metodo é uma espécie de get que temos em outras linguagens de programção orientada a objetos. */
    public function renderizar(): string
    {
        
        /*Dentro do método iremos usar a palavra reservada this para acessar a variável texto e o metodo privado filtrar que terá uma mensagem como parametro  */

        /*Retorno do resultado do metodo */
        return $this->texto;


    }

    /*Agora vamos criar um metodo chamado renderizarCss que será encadeado com o metodo suceesso */

    public function renderizarCss():String{

        return "<div class = '{$this->css}'>{$this->texto}</div>";
    }


    

    /*Agora vamos criar uma função privada que recebera uma string como parametro e retornara uma string. A função terá como objetivo filtrar o parametro mensagem. Escolhemos a visibilidade privada, pq não há a necessidade do usuário manipular a função. */
    private function filtrar(String $mensagem): string {

        /*Dentro do método, retornaremos um filtro que ira receber 2 valores a variável e o tipo de filtro que será o padrão. */
        return filter_var($mensagem, FILTER_DEFAULT);


    }
}



?>