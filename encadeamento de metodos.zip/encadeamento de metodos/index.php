

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

<?php

     /*Inclusão do arquivo  */
     include 'Mensagem.php';

     

     /*Instanciação do objeto  */
 
     $msg = new Mensagem();

     /*Como o metodo sucesso retorna um objeto e não uma string, precisamos usar o encadeamento de metodos para acessar o metodo de sucesso junto com o metodo de renderizar (que retorna strings) para acessar o valor do metodo sucesso. Dessa maneira estaremos convertendo o objeto em uma string.*/

     echo $msg->sucesso("<p>mensagem de sucesso</p>")->renderizar();

     /*Agora, vamos encadear o metodo sucesso com o metodo de renderizarCss que ira aplicar no conteudo de sucesso a estilização definida no metodo de renderizarCss. */
     echo $msg->sucesso("<p> segunda mensagem de sucesso</p>")->renderizarCss();

?>