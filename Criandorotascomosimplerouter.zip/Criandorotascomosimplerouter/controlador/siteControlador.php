


<?php

     namespace Criandorotascomosimplerouter\Controlador;


    class siteControlador{


        /*Dentro da classe iremos criar o metodo index */

        public function index(){

            
        }

    }



?>