<?php
$to = 'caike.dom@gmail.com'; // endereço do destinatario (quem vai receber)
$subject = 'Teste de envio de e-mail';/*assunto/titulo do email */
$message = 'Este é um e-mail de teste enviado pelo PHP.';/*conteudo/mensagem do email */
$headers = 'From: caike.dom@gmail.com'; // endereço do remetente quem vai receber o email

if (mail($to, $subject, $message, $headers)) {
    echo 'E-mail enviado com sucesso!';
} else {
    echo 'Falha ao enviar e-mail.';
}

?>