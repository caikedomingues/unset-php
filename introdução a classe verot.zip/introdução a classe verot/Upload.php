

<?php
    
    
        $handle = new \Verot\Upload\Upload($_FILES['arquivo']);
        if ($handle->uploaded) {
            $handle->process('uploads/documentos');
            $handle->file_new_name_body   = 'image_resized';
            $handle->image_resize         = true;
            $handle->image_x              = 100;
            $handle->image_ratio_y        = true;
            $handle->process('uploads/documentos');
            if ($handle->processed) {
                echo 'arquivo enviado com sucesso';
                $handle->clean();
            } else {
                echo 'error : ' . $handle->error;
            }
        }

?>