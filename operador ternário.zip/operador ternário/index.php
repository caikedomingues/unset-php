

<?php


/*Operadores ternários: Uma forma curta de utilizar comandos ifs */

$valor = 5;

/*Ao invés de verificarmos o valor da variavel com uma estrutura condicional if, vamos usar o operador ternário.
 */

/*Basicamente o comando ira verificar se o valor ou variável existe e caso a afirmação esteja correta (verdadeira) ele ira imprimir o valor da variável. Caso contrário ele ira atribuir o valor 0 a variável. */
 echo ($valor? $valor: 0);

 /*Também podemos fazer sem os parenteses */

 $valor = 56;

 echo "<br>";
 echo  $valor?$valor: 0;

 /*Aqui vamos incluir o arquivo funcao.php e chamar a função que recebera como parametro a 
 variável valor */

 include 'funcao.php';

 echo "<p>".formatarValor($valor)."</p>";


?>