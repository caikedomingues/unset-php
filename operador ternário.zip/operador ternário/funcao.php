

<?php

    /*Agora, vamos criar  uma função responsável por formatar o valor (float) que será passado pelo usuário*/

    /*A variável tera uma string como retorno */
    function formatarValor(float $valor) :String
    {

        return number_format($valor, 2, ",", ".");
    }

?>