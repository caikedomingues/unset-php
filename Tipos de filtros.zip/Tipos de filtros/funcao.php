


<?php

/*Os filtros podem fazer validações simples */

/*Para exemplificar melhor, vamos criar uma função para validar email que ira receber como parametro uma string e retornara um booleano */

function validarEmail(String $email):bool{


    /*Dentro do método iremos retornar um filtro que tem como parametro a variável email e o tipo do filtro que será utilizado */

    return filter_var($email, FILTER_VALIDATE_EMAIL);
}



/*A segunda função terá as mesmas caracteristicas do anterior, porem ele ira verificar se o endereço da url é válido */


function validarUrl(String $url): bool{

     /*Dentro do método iremos retornar um filtro que tem como parametro a variável url e o tipo do filtro que será utilizado */
    return filter_var($url, FILTER_VALIDATE_URL);
}


?>

