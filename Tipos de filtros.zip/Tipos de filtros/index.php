


<?php

    /*Nesse documento iremos incluir o arquivo funcao.php e chamar os metodos necessários para a realização da tarefa. */

    include 'funcao.php';

    /*Agora que aplicamos o filtro no método, vamos dar um var dump para "inspecionar" a variável e ver se esta verdadeiro ou falso o teste de validação do email.  */
    
    /*Nesse caso, o resultado será falso */
    echo "<p>".var_dump(validarEmail('teste'))."</p>";

    /*Agora vamos adicionar um email "verdadeiro" no método e verificar o resultado */

    echo "<p>".var_dump(validarEmail('caike.dom@gmail.com'))."</p>";

    /*será necessário trabalhar o valor para informar ao usuário o valor do resultado adquirido*/

    /*Para verificar os valores vamos criar uma estrutura condicional que ira verificar se o valor do parametro do metodo validarEmail é verdadeiro ou falso, e, dependendo da resposta, ele ira imprimir uma determinada mensagem. */
    if(validarEmail('teste@gmail.com')){

        echo "<p> email válido</p>";

    }else{

        echo "<p> email inválido </p>";
    }


    /*Verificação do valor do método de validação de url */

    if(validarUrl("https://www.youtube.com/watch?v=iTXf4cS4upk&list=PL0N5TAOhX5E9eJ9Ix6YUIgEw3lNmaIEE9&index=28")){

        echo "<p> url valida</p>";

    }else{

        echo "<p>url inválida</P>";
    }



?>