

<?php


    /*Atributos são as caracteristicas de um objeto, por exemplo, uma pessoa possui: nome, cpf, idade, entre outros. */

    /*Seguindo a aula anterior, vamos criar atributos para a classe mensagem. */

    /*Observação: Os atributos possuem 3 tipos de visibilidade: pública, protected e privada */

    /*
     Privada: só podem ser acessadas dentro da classe.

     publica: podem ser acessadas em qualquer arquivo

     protected: só podem ser acessadas pela classe mãe e pelas classes filhas.
    */
    class Mensagem{

        public  $texto = "conteudo";

        public $css;
    }
?>