





<?php
/*Inclusão do arquivo que contem o objeto */
include 'Mensagem.php';

/*Instancia do objeto */
$msg = new Mensagem();

// Acessando a propriedade $texto da instância $msg
echo "<p>".$msg->texto."</p>";


?>
