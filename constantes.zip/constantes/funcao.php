


<?php 

    /*Para definir uma variável constante (de valor imutavel) usamos o metodo define que recebe 2 parametros, o nome da constante e seu valor. */

    /*Observação: o nome de constantes sempre devem estar em maiusculo. */

    define('SITE_NOME','unset');

    define('SITE_DESCRICAO', 'unset - tecnologia');

    /*url para colocar o sistema online */
    define('URL_PRODUCAO', 'http://unset.com.br');

    /*url do localhost */
    define('URL_DESENVOLVIMENTO', 'http://localhost/unset%20php/');

    /*Outra maneira de definir constantes é atraves do comando const */

    /*não podemos utilizar const em estruturas condicionais, mas podemos utilizar o define */
    const NOME = 'Caike';

    
?>