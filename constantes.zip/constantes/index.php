



<?php


    /*Agora que já definimos as constantes, podemos chama-las em qualquer lugar do código */

    include 'funcao.php';


    echo "<p>".SITE_NOME."</p>";

    /*O metodo constant retorna o valor da variável constante */

    echo "<p>".constant('SITE_NOME')."</p>";

?>