


<?php

    /*O comando include serve para inserir um arquivo php dentro de outro */

    include 'configuracao.php';

    /*Agora o conteudo do arquivo incluido será mostrado no arquivo que o "solicitou". */

    /*tem quase a mesma função do include, porém, caso o arquivo não exista ele irá dat erro*/

    require 'configuracao.php';

    /*O require_once permite que o arquivo seja carregado uma única vez */
    require_once  'configuracao.php';

?>