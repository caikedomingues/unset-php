


<?php

    /*Nesse arquivo, vamos aprender a definir um fuso horario padrão para o nosso sistema. */

    /*Para definir um valor de fuso horario padrão, basta utilizar o metodo timezone */

    date_default_timezone_set('America/Sao_Paulo');



?>