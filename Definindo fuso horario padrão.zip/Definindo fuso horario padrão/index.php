


<?php


    /*Vamos incluir o arquivo horario.php para utilizar a função. */
    include 'horario.php';

      /*Agora que já configuramos, vamos imprimir os valores com a função date */

      $data = date('d/m/Y H:i');

      echo $data;
?>