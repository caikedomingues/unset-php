


<?php


    use Pecce\SimpleRouter\SimpleRouter;

    SimpleRouter::setDefaultNamespace('Criandorotascomosimplerouter\Controlador');

    /*Com o metodo estatico simplerouter, vamos pegar dppis parametros sendo eles: o link do nosso arquivo e um callback */
    SimpleRouter::get('http://localhost/unsetphp/Criandorotascomosimplerouter/', 'siteControlador@index');

    /*Por fim, basta dar um start e a rota estara criada */

    SimpleRouter::start();

?>