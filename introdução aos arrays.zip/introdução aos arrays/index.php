




<?php


    include 'funcao.php';


    echo dataAtual();

?>