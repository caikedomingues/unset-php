



<?php

   /*para imprimir um array, devemos especificar o seu nome e  seu indice, nesse exemplo, vamos imprimir a variável superglobal $_server que é um array. Vamos passar como endereço o http_host que tem como valor o nome do servidor */

   echo $_SERVER['HTTP_HOST'];

   /*Vamos agora passar o indice do script que esta sendo executado */

   echo "<p>".$_SERVER['SCRIPT_FILENAME']."</p>";

   /*maneiras de definir um array */

   /*Forma padrão onde os indices são definidos automaticamente */
   $meses = ['Janeiro',  'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];

    /*podemos passar os indices na hora da criação do conteudo do array */
    $meses_com_numero = [
    0 => 'janeiro',

    1 => 'fevereiro',

    2 => 'março',

    3 => 'abril',

    4 => 'maio',

    5 => 'junho',

    6 => 'julho',

    7 => 'agosto',

    8 => 'setembro',

    9 => 'outubro',

    10 => 'novembro',

    11 => 'dezembro'];
   /*Também podemos criar indices para os nossos valores, então os indices serão as iniciais de cada mês*/

   $meses_com_iniciais = ['j' => 'Janeiro', 'f' => 'fevereiro', 'm' => 'março', 'a' => 'abril', 'm' => 'maio', 'ju' => 'junho', 'jul' => 'julho', 'ag' => 'agosto', 's' => 'setembro', 'o'  => 'outubro', 'n' => 'novembro', 'd' => 'dezembro'];

   /*Assim como fizemos anteriormente, vamos acessar os 3 arrays através de indices */

   echo "<p>".$meses[0]."</p>";

   echo "<p>".$meses_com_numero[0]."</p>";

   echo "<p>".$meses_com_iniciais['j']."</p>";
    

   /*Para imprimir todos os valores do array, utilizamos a função foreach. Para funcionar passamos como parametro o array e um nome de nossa escolha.*/

   echo "<h2> mes com indice automatico</h2>";
   foreach($meses as $mes){

        echo "<p> $mes </p>";

   }

    
   echo "<h2>meses com indices textuais</h2>";

   foreach($meses_com_iniciais as $mes_inicial){

        echo "<p> $mes_inicial </p>";
   }

   echo "<h2> meses com indices numéricos</h2>";
   foreach($meses_com_numero as $mes_numero){

        echo "<p> $mes_numero</p>";
   }

   /*Também é possivel imprimir os indices */

   echo "<h2> meses com indices</h2>";
   foreach($meses_com_numero as $indice => $valor){

        echo "<p> $indice - $valor</p>";
   }


   echo "<h2> utilização da função dataAtual</h2>";

   /*Vamos criar uma função para imprimir a data de maneira formatada. A função não terá parametros e retornara uma string */
   function dataAtual():string

   {
        /*Antes de iniciar, vamos configurar a hora do sistema */
        date_default_timezone_set('America/Sao_Paulo');

        /*Vamos definir o dia do mes, os dias da semana, os meses e o ano */
        $diaMes = date('d');

        $diaSemana = date('w');

        /*Como os arrays iniciam com o indice 0, vamos decrementar 1 da contagem de indices. */
        $mes = date('n') - 1;

        $ano = date('Y');

        /*Agora vamos criar um array para cada categoria */

        $nomesDiasDaSemana = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sabado'];

        $nomesDosMeses = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro','novembro', 'dezembro'];

        /*Agora vamos formatar a data para o usuário */

        /*Os indices dos arrays serão as variáveis de dia da semana e mes que conteram os indices dos nomes para dias e meses */
        $dataformatada = $nomesDiasDaSemana[$diaSemana]. ' '.$diaMes. ' de '.$nomesDosMeses[$mes]. ' de '.$ano;

        /*Retorno do resultado */
        return $dataformatada;
   }

   

?>