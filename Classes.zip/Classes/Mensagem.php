


<?php

    /*Classes são abstrações do mundo real e geralmente possuem atributos e metodos */

    /*Observação: Assim como em java, o nome do arquivo deve ser igual ao nome da classe */
    class Mensagem{

            

    }
?>