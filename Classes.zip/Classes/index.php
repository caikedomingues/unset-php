



<?php

    include 'Mensagem.php';

    /*Agora que ja incluimos o arquivo no index, vamos instanciar a classe */
    /*Instanciação / criação da classe */
    $msg = new Mensagem();


?>