


<?php


    $texto = "<h1> Texto</h1>";

    echo $texto;

    /*A função strip_tags() serve para limpar/remover tags do código php, ela recebe como parametro a variável que terá as tags removidas*/

    $remocao_de_tags = strip_tags($texto);

    echo $remocao_de_tags;
?>





