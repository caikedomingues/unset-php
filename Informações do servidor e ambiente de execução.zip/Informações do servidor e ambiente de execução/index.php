



<?php


    include 'funcao.php';

    /*Após incluir o arquivo funcao.php, vamos chamar o metodo para verificar o nome do servidor */


    echo localhost();

    /*Agora vamos validar a mensagem que ira aparecer para o usuário após a verificação do nome do servidor. */

    if(localhost() == 1){

        /*Se o resultado do retorno do método for igual a 1: verdadeiro, ele ira informar "nome de servidor válido" */
        echo "<p>nome de servidor válido</p>";

    }else{

        /*Caso contrário, ele ira receber " nome de servidor inválido" */
        echo "<p> nome de servidor inválido</p>";
    }



    /*Chamada do metodo url */

    echo url('admin');

?>