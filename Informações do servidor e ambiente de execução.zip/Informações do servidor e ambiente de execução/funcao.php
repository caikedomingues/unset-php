


<?php


    /*Para adqurir informações do servidor vamos utilizar a variável superglobal  */

    //var_dump($_SERVER);


    /*Para exemplificar melhor, vamos criar uma função, para verificar se o nome do servidor é válido. Essa função terá retorno booleano e não coterá parametros. */

    function localhost(): bool
    {

        /*Dentro do método, vamos criar uma variável que ira receber um filtro input que ira receber a string "server_name" e o tipo FILTER_DEFAULT.*/

        $servidor = filter_input(INPUT_SERVER, 'SERVER_NAME',FILTER_DEFAULT);

        /*Agora que ja temos o filtro ira verificar ou "pegar" o nome, mas vamos criar uma estrutura de condições para verificar o valor. */

        if($servidor == "localhost"){
            
            /*Se o nome do servidor for localhost, a função ira retornat verdadeiro.*/
            return true;

        }else{

            /*Se o nome for diferente de localhost, afunção ira retornar falso. */
            return false;
        }
    }



    /*Definição de constantes */

    define('URL_PRODUCAO', 'http://unset.com.br');

    define('URL_DESENVOLVIMENTO', 'http://localhost/unset%20php/');

    /*Após a definição das constantes, vamos criar uma função que terá o obejtivo de atribuir a url apropriada para a variável ambiente. A função terá uma string como parametro e retornara um valor do tipo string*/

    
    function url(string $url): string
    {

          /*Dentro do método, vamos criar uma variável que ira receber um filtro input que ira receber a string "server_name". */

          $servidor = filter_input(INPUT_SERVER, 'SERVER_NAME');

          /*Após a criação do filtro, vamos criar a variável ambiente que ira receber um operador ternário para verificar o resultado do filtro de nome do servidor. */

          /*O operador ternário irá verificar se o nome é igual a localhost: se o nome for igual a variavel ambiente ira receber a url de desenvolvimento, caso contrário, iremos atribuir a url de produção.  */
          $ambiente = ($servidor == 'localhost'? URL_DESENVOLVIMENTO: URL_PRODUCAO);

          /*No retorno basta concatenar a variável ambiente com a variável url. */
          return  $ambiente.$url;
    }


?>