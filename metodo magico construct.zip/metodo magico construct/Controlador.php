


<?php

    class Controlador{

        /*Por padrão as classes possuem construtor, só que sem parametros. Os construtores servem para inicializar as variáveis e darem valores padrões a elas. */


        /*A função construct serve para realizar uma tarefa que sera executada após a instanciação de um objeto. Nesse caso, vamos apresentar uma mensagem que indicara que um objeto foi criado. */
        public function __construct(){

            echo '<p>foi iniciado</p>';

        }
       

    }


    /*Os construct também podem conter parametros. Para demonstrar a utilização, vamos criar uma segunda classe. */

    class Controlador2{

        /*Como o construct possui parametros, somos obrigados a passar parametros na instanciação do objeto. Podemos ter quantos parametros quisermos, independente do seu tipo.*/
        public function __construct(String $tema){

            echo $tema;
        }
    }




?>