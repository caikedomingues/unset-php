



<?php

    include 'Controlador.php';

    $controlador = new Controlador();

    
    $controlador2 = new Controlador2('Controlador2 iniciado');



?>