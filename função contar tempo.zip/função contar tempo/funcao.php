

<?php

    /*Para iniciar a criação vamos definir uma função para contagem do tempo */

    /*A função ira receber como parametro uma variável do tipo string */
    function contarTempo(String $data){

        /*ajuste do fuso horario local */
        date_default_timezone_set('America/Sao_Paulo');

        /*Para contar o tempo, é necessário converte-lo em segundos, para isso, vamos utilizar a função strtotime que ira receber como parametro a função date */
       $agora = strtotime(date('d/m/Y H:i:s'));

        /*Agora vamos criar uma variável tempo que ira receber o metodo strtotime com o parametro $data. */

        $tempo = strtotime($data);

        /*Agora vamos calcular a diferença entre eles */

        $diferenca = $agora - $tempo;

        /*Para iniciar os cálculos vamos atribuir a variável segundos o valor da diferenca*/

        $segundos = $diferenca;
        
        /*Na variável minutos vamos atribuir a função round que tem como objetivo arredontar valores com a maior precisão possivel.
           Vamos pegar o valor retornado pelo round e dividir por 60 (1 minuto possui 60 segundos).
        */
        $minutos = round($diferenca / 60);

        /*Com as horas, vamos seguir a mesma lógica, porém, vamos dividir a diferença  por 3600, pois, uma hora tem 3600 segundos*/
        $hora = round($diferenca / 3600);

        /*No calculo da quantidade de segundos por dia, basta pegar 3600 (quantidade de segundos em 1 hora) vezes 24 (quantidade de horas de 1 dia )e dividir o resultado pela diferença*/
        $dia = round($diferenca / 86400);

        /*No cálculo de semanas vamos multiplicar 86400 (quantidade de segundos em 1 dia) vezes 7 (quantidade de dias na semana) e dividir o resultado pela diferença. */
        $semanas = round($diferenca / 604800);
        
        /*No cálculo dos meses vamos multiplicar 604800 (quantidade de segundos em 1 semana) vezes 4 (quantidade de semanas em 1 mês) e dividir o resultado pela diferença*/

        $meses = round($diferenca / 2419200);

        /*No cálculo dos anos, vamos mulltiplicar o 2419,200 (quantidade de segundos em 1 mes) vezes 12(quantidade de meses do ano) e dividir o resultado pela diferença */
        $ano = round($diferenca / 29030400);

       

        if($segundos <= 60){

             /*Verificação se o valor do segundo é menor ou igual a 60. Caso a afirmação seja verdadeira ele ira informar a palavra 'agora' */
            return 'agora';

        }else if($minutos <= 60){

            /*Se os minutos forem menor ou igual a 60, vamos verificar através de operadores ternários, se o valor é igual a 1: Caso a condição esteja como verdadeira vamos escrever a mensagem 'há 1 minuto', senão, vamos escrever 'há valor minutos'. */
            return $minutos == 1? 'há 1 minuto': 'há '.$minutos.' minutos ';

        }else if($hora <= 24){
            
            /*Se as horas forem menores ou igual a 24 horas, vamos verificar através dos operadores ternários, se o valor é igual a 1: Caso a condição esteja como verdadeira vamos escrever a mensagem 'há 1 hora', senão, vamos escrever 'há valor horas' */
            return $hora == 1?'há 1 hora': 'há '.$hora.' horas';

        }else if($dias <= 7){

               /*Se os dias forem menores ou iguais a 7, vamos verificar através dos operadores ternários, se o valor é igual a 1: Caso a condição esteja como verdadeira vamos escrever a mensagem 'há 1 dia', senão, vamos escrever 'há valor dias' */
            return $dias == 1 ? 'há 1 dia ': 'há'.$dias.' dias';

        }else if($semanas <= 4){
            
            /*Se as semanas forem menores ou iguais a 4, vamos verificar através dos operadores ternários, se o valor é igual a 1: Caso a condição esteja como verdadeira vamos escrever a mensagem 'há 1 semana', senão, vamos escrever 'há valor semanas.' */
            return $semanas == 1 ? 'há 1 semana': 'há '.$semanas. ' semanas';

        }else if($meses <= 12){
             /*Se os meses forem menores ou iguais a 12, vamos verificar através dos operadores ternários, se o valor é igual a 1: Caso a condição esteja como verdadeira vamos escrever a mensagem 'há 1 mês', senão, vamos escrever 'há valor meses.' */

            return $meses == 1? 'há 1 mês': 'há '.$meses.' meses';

        }else if($ano <= 1){

            /*Se os anos forem menores ou iguais a 1, vamos verificar através dos operadores ternários, se o valor é igual a 1: Caso a condição esteja como verdadeira vamos escrever a mensagem 'há 1 ano', senão, vamos escrever 'há valor anos.' */

            return $ano == 1? 'há 1 ano': 'há '.$ano.' anos';
        }


        


       

    }
?>