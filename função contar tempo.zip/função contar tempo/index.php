



<?php


    /*No documento principal iremos incluir o arquivo funcao.php que contém a função que iremos chamar */


    include 'funcao.php';

    echo contarTempo('06/02/2024 13:47:15');


?>