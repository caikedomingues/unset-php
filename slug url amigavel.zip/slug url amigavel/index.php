





<?php

    include 'funcao.php';

    echo "<p>". slug("Adão \"Negro\" - '2022' ")."</p>";

    echo "<p>".slug("Avatar 2: o caminho da água")."</p>";

    echo "<p>".slug("Não! Não olhe")."</p>";

    echo "<p>".slug("Sonic 2 - O filme")."</p>";

    echo "<p>".slug("NOVA SÉRIE NO DISNEY!")."</p>";

    echo "<p>".slug("100 melhores filmes")."</p>";

    echo "<p>".slug("teste !!!@@@@");


?>