
<!DOCTYPE htmL>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale 1.0">
        <meta http-equiv="X-UA Compatible" content="IE-edge">
        <link rel="stylesheet" href="estilo/pesquisar.css">
        <link rel="shotcuts icon" href="imagens/logo.jpg">
    </head>

    <body>
        <header>
                <nav class="menu">

                    <input type="checkbox" class="menu-faketrigger">
                    <div class="menu-lines">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <ul>
                        <li class="login"><a href="index.php">Login</a></li>
                        <li><a href="Cadastro.php">Cadastrar</a></li>
                        <li><a href="Atualizar.php"> Atualizar</a></li>
                        <li><a href="Deletar.php">Deletar</a></li>
                        <li class="pesquisar"><a href="#">Pesquisar</a></li>
                    </ul>
                </nav>
                <h1>Como validar usuários</h1>
            </header>
         <section>
            <?php

                /*Coleta dos dados com um filtro do tipo array */
                $dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);
            ?>

            <img src="imagens/perfil.png" alt="imagem de perfil" class="imagem-perfil">
            <form action="<?php $_SERVER['PHP_SELF']?>" method="post">

                <label for="id">ID: </label>
                <input type="number" name="id" required autocomplete="off" class="input-email">

                <input type="submit" value="Pesquisar" class="botao-entrar">
            </form>

            <?php

                /*Antes de realizar a instancia do objeto Dados e a chamada dos metodos temos que verificar
                se os campos do formulário foram preenchidos */
                if(!empty($dados['id'])){

                    include 'Dados.php';

                    $valor = new Dados();

                    $valor->Pesquisar($dados);
                }
            ?>
         </section>
    </body>
</html>