



<?php

    
    class Dados{

        /*Metodo responsável por checar os dados. Ele ira receber um parametro do tipo array e retornara um valor booleano. */
        public function checarDados(array $dados): bool{
            
            /*primeiro, vamos verificar se o indice email do array dados está vázio. */
            if(empty($dados['email'])){

                /*Caso o campo esteja vázio o programa ira soltar um alerta e retornara falso não deixando a informação ser registrada*/
                echo "<script> alert('o campo email é obrigatório')</script>";

                return false;

            }else if(empty($dados['senha'])){

                /*agora vamos verificar se o indice senha do array dados está vázio. */

                /*Caso o campo esteja vázio o programa ira soltar um alerta e retornara falso não deixando a informação ser registrada*/
                echo "<p><script> alert('o campo senha é obrigatório')</script></p>";

                return false;

            }
            

            /*Caso os campos estejam preenchidos o programa retornara verdadeiro e seguira normalmente */

            return true;
        }



        /*Metodo para conexao com o banco de dados mysql */

        private function conectar(){

            try{

                /*Dentro da instância, vamos colocar o código padrão, o nome do servidor, a porta do mysql, 
                o nome do banco de dados, o usuário e a senha. */
                $conexao = new PDO('mysql:host=localhost;port=3306;dbname=criandousuario','root','');

                return $conexao;

            }catch(PDOException $erro){

                /*Exceção que ira informar o usuário em casos de erro */
                echo "<script>alert('Erro na conexão com o banco de dados: ')</script>";
            }

        }

        public function login(array $dados){

                /*Chamada da conexão com o banco de dados */
                $conexao = $this->conectar();  

                /*Seleção que ira percorrer todo o banco de dados para verificar a existência do dado pesquisado */
                $resultado  = $conexao->query("SELECT * FROM usuario WHERE email = '".$dados['email']."' AND senha = '".$dados['senha']."'");

                /*Ira contar as linhas do banco de dados que contem o valor procurado */
                $quantidade_linhas = $resultado->rowCount();

                /*SE a quantidade de linhas encontradas com os valores forem maior que 0 */
                if($quantidade_linhas > 0){
                    /*O programa ira dar um alert com a mensagem informando ao usuário que o login
                    foi encontrado. */
                    echo "<script>alert('Usuário encontrado com sucesso');</script>";

                    /*Como o pdo nos devolve os dados em forma de um array associativo, vamos coloca-lo em
                    um loop e enquanto ele encontrar o dado no banco ele ira verificar o nivel do usuário
                    para imprimir a mensagem correta*/
                    

                while($dados = $resultado->fetch(PDO::FETCH_ASSOC)){

                        /*Caso  o usuário encontrado tenha um nivel maior que 1 ele receber a mensagem
                        de boas vindas*/
                        if($dados['level'] > 1){
                        
                        /*Impressão da mensagem com o conteudo da coluna nome, que é o indice
                        do array associativo */
                        echo "<p>Seja bem vindo ".$dados['nome']."</p>";
                        
                        /*Agora precisamos atualizar a coluna de ultimo login, para isso, vamos ajustar o 
                        fuso horário do nosso sistema */
                        date_default_timezone_set("America/Sao_Paulo");
                        /*Após configurar a data vamos atribuir o valor a variável data */
                        $data = date("Y-m-d H:i:s"); 
                        /*Agora, basta atualizar a coluna com a data atual do sistema no mysql */
                        $resultado = $conexao->query("UPDATE usuario SET ultimo_login = '".$data."' Where email = '".$dados['email']."'");
        

                        }else{

                            /*Casp o usuario tenha um nivel abaixo de 2 ele terá o acesso negado */
                            echo "<script>alert('o acesso para usuários menores que nivel 2 não é permitido');</script>";
                        }
                }

                }else{

                    /*Caso o usuario não seja encontrado */
                    echo "<script>alert('Usuário não encontrado');</script>";

                    
                }
        

                


        }


        public function cadastrar(array $dados ){

            try{

                  /*Primeiro temos que chamar o metodo que ira se conectar ao banco de
                   dados */
                 $conexao = $this->conectar();

                 $resultado = $conexao->query("INSERT INTO usuario(nome, email, senha) VALUES('".$dados['nome']."', '".$dados['email']."', '".$dados['senha']."')");

                echo "<p><script>alert('O usuário(a) ".$dados['nome']." foi cadastrado(a) com sucesso')</script></p>";

                

            }catch(PDOException $erro){

                echo "<p><script>alert('Não foi possivel cadastrar o usuário: $erro');</script></p>";
            }
        }

        public function atualizar(array $dados){

            /*Chamada da conexão com o banco de dados*/
    
            $conexao = $this->conectar();
    
            /*Comando para percorrer o banco de dados */
            $selecao = $conexao->query("SELECT * FROM usuario Where id= '".$dados['id']."'");
    
            /*Comando para contar a quantidade de linhas no banco de dados */
    
            $quantidade_linhas = $selecao->rowCount();
    
            /*Verificação das linhas encontradas */
            if($quantidade_linhas > 0){
    
                /*Caso o sistema encontre 1 ou mais linhas ele ira imprimir uma mensagem e atualizar
                os cadastros */
                echo "<script>alert('Dados atualizados com sucesso')</script>";
    
                $atualizarNome = $conexao->query("UPDATE usuario SET nome='".$dados['nome']."' WHERE id='".$dados['id']."'");
    
                $atualizarSenha = $conexao->query("UPDATE usuario set senha='".$dados['senha']."' WHERE id='".$dados['id']."'");
    
                $atualizarEmail = $conexao->query("UPDATE usuario SET email='".$dados['email']."' Where id='".$dados['id']."'");

                /*atualizando a coluna 'atualizado_em', para isso, vamos ajustar o 
                fuso horário do nosso sistema */
               date_default_timezone_set("America/Sao_Paulo");

               /*Após configurar a data vamos atribuir o valor a variável data */
               $data = date("Y-m-d H:i:s"); 

               $atualizar_hora = $conexao->query("UPDATE usuario SET atualizado_em = '$data' WHERE id='".$dados['id']."'");

                
    
            }else{
    
                /*Caso contrário, o sistema não irá atualizar os dados e informara o usuário. */
                echo "<script>alert('Não é possivel atualizar dados inexistentes')</script>";
    
            }
    
        }


        public function Apagar(array $dados){

            /*Chamada do metodo de conexão com banco de dados */
            $conexao = $this->conectar();

            /*Variável que ira percorrer o banco de dados para verificar so id informado
            existe. */
            $selecao = $conexao->query("SELECT * FROM usuario WHERE id='".$dados['id']."'");

            /*Ira contar a quantidade de linhas do banco de dados. */
            $quantidade_linhas = $selecao->rowCount();

            /*Ira verificar a quantidade de linhas encontradas */
            if($quantidade_linhas > 0){

                /*Se o sistema encontrar o o id informado, o cadastro será apagado */
                echo "<script>alert('Dados apagados com sucesso')</script>";

                $resultado = $conexao->query("DELETE FROM usuario WHERE id='".$dados['id']."'");

            }else{

                /*Caso contrário, o sistema ira informar o usuario que o cadastro não existe */
                echo "<script>alert('Não é possivel apagar um usuário inexistente')</script>";
            }
        }

        public function pesquisar(array $dados){

            /*Chamada da conexao com o banco de dados */
            $conexao = $this->conectar();

            /*Variável que ira percorrer o banco de dados */
            $selecao = $conexao->query("SELECT * FROM usuario WHERE id='".$dados['id']."'");

            /*Quantidade delinhas encontradas */
            $quantidade_linhas = $selecao->rowCount();

            if($quantidade_linhas > 0){

                /*Se a quantidade de linhas encontradas, for maior que 0, vamos informar
                ao usuário que um cadastro foi encontrado  */
                echo "<script>alert('Usuário encontrado com sucesso')</script>";

                /*Vamos selecionar os dados que devem ser apresentados */
                $resultado = $conexao->query("SELECT nome, email FROM usuario WHERE id='".$dados['id']."'");

                /*Vamos criar um for que ira imprimir os resultados solicitados */
                foreach($resultado as $dado){

                    echo "<p> Nome: ".$dado['nome']."</p>";
                    echo "<p> Email: ".$dado['email']."</p>";
    
                }

            }else{

                /*Caso não exista um cadastro, vamos informar ao usuário que o valor
                informado não existe no banco de dados */
                echo "<script>alert('Usuário não encontrado')</script>";
            }
        }
    


    }


   

?>




