

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale 1.0">
        <meta http-equiv="X-UA Compatible" content="IE-edge">
       <link rel="stylesheet" href="estilo/login.css">
        <link rel="shotcuts icon" href="imagens/logo.jpg">
        <title>Como validar usuários</title>
    </head>

    <body>
        <header>
            <nav class="menu">

                <input type="checkbox" class="menu-faketrigger">
                <div class="menu-lines">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <ul>
                    <li class="login"><a href="index.php">Login</a></li>
                    <li><a href="Cadastro.php">Cadastrar</a></li>
                    <li><a href="Atualizar.php"> Atualizar</a></li>
                    <li><a href="Deletar.php">Deletar</a></li>
                    <li><a href="Pesquisar.php">Pesquisar</a></li>
                </ul>
            </nav>
            <h1>Como validar usuários</h1>
         </header>

          <section>

            <?php
            
                /*Aqui, vamos trabalhar a captura dos valores através de filtros */

                $dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

                /*Vamos verificar se os dados estão chegando no formulário */
               // var_dump($dados);
            ?>
            <img src="imagens/perfil.png" alt="imagem de perfil" class="imagem-perfil">
            <form action="<?php $_SERVER = ['PHP_SELF']?>" method="post">

            <label for="email" class="label-email">Email:</label>
            <input type="text" name="email" id="idemail"  autocomplete="off"  class="input-email"><br>

            <label for="senha" class="label-senha">Senha:</label>
            <input type="password" name="senha" id="idsenha"  autocomplete="off" class="input-senha"><br>

            <input type="submit" value="Entrar" class="botao-entrar">

            <p><a href="Cadastro.php">Não possui um cadastro? Clique aqui</a></p>
            <?php

                 if(!empty($dados['email']) && !empty($dados['senha'])){

                    include 'Dados.php';

                    $valor = new Dados();

                    /*Como eu não quero que o valor 1 apareça na tela em caso de resultado
                    verdadeiro, vanos atribuir a chamada do metodo a uma variável */
                    $resultado = $valor->checarDados($dados);
                    
                    /*Após atribuir o valor a variável resultado, vamos verificar se o resultado
                    retornado é verdadeiro */
                    if($resultado){
                        /*Caso o resultado seja verdadeiro, ele ira imprimir a mensagem abaixo */
                        echo "<p> <script> alert('Dados enviados com sucesso')</script></p>";

                        $valor->login($dados);
                    };
                

                 }
                   
            ?>
         </section>

       
      </form>
    </body>
</html>