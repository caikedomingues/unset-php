
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width, device-width, initial-scale 1.0">
        <meta http-equiv="IE-edge" content="X-UA Compatible">
        <link rel="stylesheet" href="estilo/cadastro.css">
        <link rel="shotcuts icon" href="imagens/logo.jpg">
    </head>


    <body>
        <header>
            <nav class="menu">

                <input type="checkbox" class="menu-faketrigger">
                <div class="menu-lines">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <ul>
                    <li><a href="index.php">Login</a></li>
                    <li class="cadastro"><a href="#">Cadastrar</a></li>
                    <li><a href="Atualizar.php"> Atualizar</a></li>
                    <li><a href="Deletar.php">Deletar</a></li>
                    <li><a href="Pesquisar.php">Pesquisar</a></li>
                </ul>
            </nav>
            <h1>Como validar usuários</h1>
        </header>
        <section>

            <?php
            
                $dados = filter_input_array(INPUT_POST,FILTER_DEFAULT);

                /*Serve para verificar se o filtro está recebendo os valores */
                //var_dump($dados);
            
            ?>

            <img src="imagens/perfil.png" alt="Foto de perfil" class="imagem-perfil"> 
            <form action="<?php $_SERVER=['PHP_SELF']?>" method="post">

                <label for="nome"> Nome:</label>
                <input type="text" name="nome" autocomplete="off" required class="input-email"><br>

                <label for="email">Email:</label>
                <input type="text" name="email" autocomplete="off" required class="input-email"><br>

                <label for="senha">Senha:</label>
                <input type="password" name="senha" autocomplete="off" required class="input-email"><br>

                <label for="confirme">Conf.senha:</label>
                <input type="password" name="confirme" autocomplete="off" required class="input-email"><br>

                <input type="submit" Value="Cadastrar" class="botao-entrar">



            </form>

            <?php

                /*Basicamente estou verificando se a variável não está vazia. Caso a afirmação seja verdadeira,
                ele ira realizar as outrasverificações e chamar os metodos necessários para cadastrar os usuários */
                if (!empty($dados['nome']) && !empty($dados['email']) && !empty($dados['senha']) && !empty($dados['confirme'])){

                    /*Nessa parte, vamos verificar se os campos senha e conf.senha foram inicializados e caso eles 
                    ja tenham um valor ele ira verificar se os campos senha e conf.senha são iguais.
                        Caso os campos tenham valores diferentes ele ira informar o usuário e não chamara o método
                    */
                    if(isset($dados['senha']) && isset($dados['confirme']) && $dados['senha'] != $dados['confirme']) {
                        echo "<p>Os campos senha e confirmação de senha devem ser iguais.</p>";
    
                    }else{

                        /*Se todas as consdições forem satisfeitas o metodo de cadastro de usuários
                        será chamado */
    
                        include 'Dados.php';
    
                         $valor = new Dados();
                         $valor->cadastrar($dados); // Chama o método de cadastro
                    }

                };
               

            
            ?>
        </section>
    </body>
</html>