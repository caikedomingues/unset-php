


create database criandousuario;

use criandousuario;

create table usuario(
	
    id int auto_increment,
	level int Default 1, /*irá fazer referencia aos campos ou páginas que o usuário pode ou não acessar.
    Terá como valor padrão o 1.*/
    nome varchar(255),
    email varchar(255) unique,
    senha varchar(255),
    status int DEFAULT 0,
    ultimo_login datetime default null,/*Ira mostrar a ultima vez que o usuário realizou um login*/
    cadastrado_em  timestamp DEFAULT current_timestamp, /*A função current_timestamp retorna a data e hora atual do sistema 
    sempre que um novo registro é inserido na tabela. Ja o timestamp serve para armazenar valores de data e hora.*/
    atualizado_em datetime Default null,
    
    primary key(id)
    
)default charset = utf8;

/*Teste de inserção de dados*/

insert into usuario(nome, email, senha) values('caique', 'caique@gmail.com', '1234');

insert into usuario(level, nome, email, senha) values('2', 'caua','caua@gmail.com','2345');

select * from usuario;