





<?php

/*switch case: é uma espécie de estrutura condicional, onde cada caso carrega um bloco de código com a finalidade de realizar uma determinada tarefa */

 
/*Como exercicio irei criar uma variável hora que ira receber a função date com parametro 'H' (hora)   */

date_default_timezone_set('America/Sao_Paulo');

$hora = date('H:i');

/*Agora vamos utilizar o switch case para validar o resultado retornado pela função. Para usar a estrutura é necessário passar como parametro a variável que será analisada. */

switch($hora){

    /*Dentro do switch vamos criar os casos e suas condições */
    case $hora >= 0 and $hora <= 5:

        /*Se o horário estiver entre meia noite e 5 da manhã, a mensagem de saudação será 'boa madrugada' */
        echo "<p>boa madrugada, agora são $hora horas</p>";

        /*O break serve para finalizar a verificação e demonstrar o resultado, é um comando obrigatório na utilização dessa estrutura. */
        break;
    
    case $hora >= 6 and $hora <= 12:

        /*Caso o horario esteja entre 6 da manhã e meio dia, a mensagem de saudação será 'bom dia'. */
        echo "<p>bom dia, agora são $hora horas</p>";

        break;
    
        /*Caso a mensagem esteja entre as 13 e 18 a mensagem de saudação será 'boa tarde'. */
    case $hora >= 13 and $hora <= 18:

        echo "<p>boa tarde, agora são $hora horas</p>";

        break;

    case $hora > 18:

        /*Caso o horario seja maior que 18 a mesnagems será boa noite */
        echo "<p>Boa noite</p>";

        break;

        /*O comando default é um valor padrão caso nenhuma condição seja realizada */

    default:

        echo "<p> Ola usuário</p>";
        
}


?>