




<?php

include 'funcao.php';


?>